package org.mifosplatform.billing.order.data;

public class DisconnectDetails {

}
