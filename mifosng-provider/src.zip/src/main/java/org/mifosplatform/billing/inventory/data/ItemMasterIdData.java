package org.mifosplatform.billing.inventory.data;

public class ItemMasterIdData {

	private Long itemMasterId;

	public ItemMasterIdData(){}
	
	public ItemMasterIdData(Long itemMasterId){
		this.itemMasterId = itemMasterId;
	}
	
	public Long getItemMasterId() {
		return itemMasterId;
	}

	public void setItemMasterId(Long itemMasterId) {
		this.itemMasterId = itemMasterId;
	}
	
}
